%% Initialization
NrOfTrials = 10; % Number of realizations. 
M = 6; % Adaptive filter length. Do not change.

mu_LMS = ... % The step size parameter for LMS. Change.

% Create the filters using DSP System Toolbox
hLMS = ...


% Desired signal
[d, fs] = audioread('S7_Quake_III_Arena_Gameplay.wav');

e = [];
% iterate over trials
for k=1:NrOfTrials
    % Input signal
    [u, fs] = audioread(['S7_Quake_III_Arena_Gameplay_IIR_', num2str(k), '.wav']);
    u = u * 2^(24-16);
    
    % -- Use the filters -------------------------------------------------
     
    % -- Least Mean Squares algorithms
    % LMS 
    
    % NLMS
    
    % Sign-Sign LMS

    % -- Recursive Least Squares algorithms.
    % RLS
    
    % Householder RLS
    
    % Householder sliding window RLS
    
end

% -- Plot results here:
% Use legend, title, xlabel and ylabel to illustrate what is plotted.
% You can use the function semilogy to plot on logarithmic y-axis.


