%% get I and noice cancelled Im(dark to bright: 1-4)
   ph = initMeasCard;
   vid = videoinput('winvideo',1,'MJPG_800x600');
   get(vid)
   source = getselectedsource(vid);
   Source.Exposure = -11:-2;
for t = 1:10
    source.Exposure = Source.Exposure(t);
    I(t) = getIntensity(ph);
    Im(t) = getMeanIntensity(ph);
    % You may check some properties of the video input object
    
    % Look at the parameters of the active video source
    get(source)

    % Set focus manually
    %set(source,'Focus','manual');
    set(source,'Focus',25);

    % Get more info about a specific parameter (e.g. its range of values)
    propinfo(source,'Exposure')

    % Set at least these to allow manual control of the camera exposure
    set(source,'ExposureMode','manual')
 %   source.Exposure=-9;
    set(source,'BacklightCompensation','off')
    set(source,'WhiteBalanceMode','manual')

    % To see preview of the video stream, you can open a preview
    %preview(vid)

    % To close the preview:
    %closepreview(vid)

    % Before you can get images, the video source must be started
    start(vid)

    % Capturing one image
    im{t} = getdata(vid,1);
    imwrite(im{t}, ['img_expo_' num2str(source.Exposure) 'int_' num2str(getIntensity(ph)) '.jpeg'])
    imshow(im{t});
    stop(vid)
%   imaqreset
end
closeMeasCard(ph);
figure,
plot(t,I);
%% calculate the SNR
load('I1.mat')
load('I2.mat')
load('I3.mat')
load('I4.mat')
load('Im1.mat')
load('Im2.mat')
load('Im3.mat')
load('Im4.mat')
SNR1 = snr(Im1,I1-Im1);
SNR2 = snr(Im2,I2-Im2);
SNR3 = snr(Im3,I3-Im3);
SNR4 = snr(Im4,I4-Im4);

%% plot the results
figure,
subplot(4,1,1)
plot(1:10,I1,'r-',1:10,Im1,'r.-')
legend('I1','Im1 after average mean noise cancel')
subplot(4,1,2)
plot(1:10,I2,'g-',1:10,Im2,'g.-')
legend('I2','Im2 after average mean noise cancel')
subplot(4,1,3)
plot(1:10,I3,'b-',1:10,Im3,'b.-')
legend('I3','Im3 after average mean noise cancel')
subplot(4,1,4)
plot(1:10,I4,'k-',1:10,Im4,'k.-')
legend('I4','Im4 after average mean noise cancel')

figure,
plot(1:4,[SNR1,SNR2,SNR3,SNR4],'o')