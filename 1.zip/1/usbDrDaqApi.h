#ifndef __USBDRDAQAPI_H__
#define  __USBDRDAQAPI_H__

#define USB_DRDAQ_MAX_AWG_VALUE 1000

#include "PicoStatus.h"

#ifdef PREF0
  #undef PREF0
#endif
#ifdef PREF1
  #undef PREF1
#endif
#ifdef PREF2
  #undef PREF2
#endif
#ifdef PREF3
  #undef PREF3
#endif

#ifdef __cplusplus
  #define PREF0 extern "C"
#else
  #define PREF0
#endif

  //If you are dynamically linking USBDrDAQ.DLL into your project #define DYNLINK here
  #ifdef DYNLINK
    #define PREF1 typedef
    #define PREF2
    #define PREF3(x) (__stdcall *x)
  #else
    #define PREF1
    #ifdef _USRDLL
      #define PREF2 __declspec(dllexport) __stdcall
    #else
      #define PREF2 __declspec(dllimport) __stdcall
    #endif
    #define PREF3(x) x
  #endif
#else
  #ifdef DYNLINK
    #define PREF1 typedef
    #define PREF2
    #define PREF3(x) (*x)
  #else
    #ifdef _USRDLL
      #define PREF1 __attribute__((visibility("default")))
    #else
      #define PREF1
    #endif
    #define PREF2
    #define PREF3(x) x
  #endif
  #define __stdcall
#endif

typedef enum enUsbDrDaqInputs
{
 	USB_DRDAQ_CHANNEL_EXT1 = 1,				//Ext. sensor 1
  USB_DRDAQ_CHANNEL_EXT2,						//Ext. sensor 2
  USB_DRDAQ_CHANNEL_EXT3,						//Ext. sensor 3
	USB_DRDAQ_CHANNEL_SCOPE,					//Scope channel
  USB_DRDAQ_CHANNEL_PH,							//PH
	USB_DRDAQ_CHANNEL_RES,						//Resistance
  USB_DRDAQ_CHANNEL_LIGHT,					//Light
	USB_DRDAQ_CHANNEL_TEMP,						//Thermistor
  USB_DRDAQ_CHANNEL_MIC_WAVE,				//Microphone waveform
	USB_DRDAQ_CHANNEL_MIC_LEVEL,			//Microphone level
	USB_DRDAQ_MAX_CHANNELS = USB_DRDAQ_CHANNEL_MIC_LEVEL
} USB_DRDAQ_INPUTS;

typedef enum enUsbDrDaqScopeRange
{
	USB_DRDAQ_1V25,
	USB_DRDAQ_2V5,
	USB_DRDAQ_5V,
	USB_DRDAQ_10V
}USB_DRDAQ_SCOPE_RANGE;

typedef enum enUsbDrDaqWave
{
	USB_DRDAQ_SINE,
	USB_DRDAQ_SQUARE,
	USB_DRDAQ_TRIANGLE,
	USB_DRDAQ_RAMP_UP,
	USB_DRDAQ_RAMP_DOWN,
	USB_DRDAQ_DC
}USB_DRDAQ_WAVE;

typedef enum enUsbDrDaqDO
{
	USB_DRDAQ_GPIO_1 = 1,
	USB_DRDAQ_GPIO_2,
	USB_DRDAQ_GPIO_3,
	USB_DRDAQ_GPIO_4
}USB_DRDAQ_GPIO;

typedef enum enUSBDrDAQInfo
{
  USBDrDAQ_DRIVER_VERSION,
  USBDrDAQ_USB_VERSION,
  USBDrDAQ_HARDWARE_VERSION,
  USBDrDAQ_VARIANT_INFO,
  USBDrDAQ_BATCH_AND_SERIAL,
  USBDrDAQ_CAL_DATE,	
  USBDrDAQ_KERNEL_DRIVER_VERSION, 
  USBDrDAQ_ERROR,
	USBDrDAQ_SETTINGS,
} USBDrDAQ_INFO;
											
#ifndef BM_DEFINED
#define BM_DEFINED
typedef enum _BLOCK_METHOD{BM_SINGLE, BM_WINDOW, BM_STREAM} BLOCK_METHOD;
#endif

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqOpenUnit)
(
	short *handle
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqCloseUnit)
(
	short handle
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqGetUnitInfo)
(	
	short			handle,		
	char			*string, 
	short			stringLength, 
	short			*requiredSize, 
	PICO_INFO info
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqRun) 
(
	short						handle, 
	unsigned long		no_of_values, 
	BLOCK_METHOD		method
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqReady)
(
	short handle, 
	short *ready
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqStop) 
(
	short handle
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqSetInterval)
(	
	short							handle,
	unsigned long			*us_for_block,
	unsigned long			ideal_no_of_samples,
	USB_DRDAQ_INPUTS	*channels,
	short							no_of_channels
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqSetTrigger)
(
	short						handle,
	unsigned short	enabled,
	unsigned short	auto_trigger,
	unsigned short	auto_ms,
	unsigned short	channel,
	unsigned short	dir,
	short						threshold,
	unsigned short	hysterisis,
	float						delay
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqGetValues) 
(
	short						handle,
	short						*values,
	unsigned long		*noOfValues, 
	unsigned short	*overflow,
	unsigned long		*triggerIndex
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqGetTriggerTimeOffsetNs)	
(
	short		handle, 
	__int64 *time
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqGetSingle) 
(
	short							handle, 
	USB_DRDAQ_INPUTS	channel, 
	short							*value, 
	unsigned short		*overflow
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqOpenUnitAsync) 
(
	short *status
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqOpenUnitProgress) 
(
	short *handle, 
	short *progress, 
	short *complete
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqGetScalings)
(
	short							handle, 
	USB_DRDAQ_INPUTS	channel, 
	short							*nScales, 
	short							*currentScale, 
	char							*names, 
	short							namesSize
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqSetScalings)
(
	short							handle, 
	USB_DRDAQ_INPUTS	channel, 
	short							scalingNumber
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqSetSigGenBuiltIn)
(
	short						handle, 
	long						offsetVoltage,
	unsigned long		pkToPk,
	short						frequency,
	USB_DRDAQ_WAVE	waveType
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqSetSigGenArbitrary)
(
	short					handle, 
	long					offsetVoltage,
	unsigned long	pkToPk,
	short					*arbitraryWaveform,
	short					arbitraryWaveformSize,
	long					updateRate
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqStopSigGen)
(
	short	handle
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqSetDO)
(
	short						handle,
	USB_DRDAQ_GPIO	IOChannel,
	short						value
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqSetPWM)
(
	short						handle,
	USB_DRDAQ_GPIO	IOChannel,
	unsigned short	period,
	unsigned char		cycle
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqGetInput)
(
	short						handle,
	USB_DRDAQ_GPIO	IOChannel,
	short						pullUp,
	short						*value
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqStartPulseCount)
(
	short						handle,
	USB_DRDAQ_GPIO	IOChannel,
	short						direction
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqGetPulseCount)
(
	short						handle,
	USB_DRDAQ_GPIO	IOChannel,
	short						*count
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqEnableRGBLED)
(
	short	handle,
	short enabled
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqSetRGBLED)
(
	short	handle,
	unsigned short	red,
	unsigned short	green,
	unsigned short	blue
);

PREF0 PREF1 PICO_STATUS PREF2 PREF3 (UsbDrDaqGetChannelInfo)
(
	short							handle,
	float							*min,
	float							*max,
	short							*places,
	short 						*divider,
	USB_DRDAQ_INPUTS	channel
);

PREF0 PREF1 PICO_STATUS PREF2  PREF3 (UsbDrDaqPingUnit) (short handle);
