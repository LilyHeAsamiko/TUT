%--------------------------------------------------------------------------
% Demosaic
%
% There are 4 different cases that can be used for R and B channels ...
%creation (Bayer pattern):
%
% a) 'grbg' -  G  R  G      
%              B  G  B 
%              G  R  G 
%              
%
% b) 'gbrg' -  G  B  G
%              R  G  R
%              G  B  G
%
%
% c) 'rggb' -  R  G  R
%              G  B  G
%              R  G  R
%
%
% d) 'bggr' -  B  G  B
%              G  R  G
%              B  G  B   
%
% Task:
% - Demosaic "rawImg" using case c). You can implement the simplest method
%of demosaicing - linear method with independent interpolation of each 
%color plane [1]. You can also implement any other method described in [1] 
%or develop your own. You are not allowed to use "demosaic" function of 
%Matlab in this task. You must describe in few sentences the bayer 
%principle and the method used for demosaicing. 
%You can compare your result with the reference image.  
%
% [1] - A. Lukin, and D. Kubasov, "An Improved Demosaicing Algorithm", 
%Graphicon, 2004.
%--------------------------------------------------------------------------
function rgb = BayerDemosaic (rawImg)

















end